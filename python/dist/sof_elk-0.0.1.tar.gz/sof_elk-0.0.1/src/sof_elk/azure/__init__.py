"""
SOF-ELK® Azure Module
"""
