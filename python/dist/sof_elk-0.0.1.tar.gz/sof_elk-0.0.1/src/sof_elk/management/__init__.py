"""
SOF-ELK® Management Module
"""
