"""
SOF-ELK® Processors Module
"""
