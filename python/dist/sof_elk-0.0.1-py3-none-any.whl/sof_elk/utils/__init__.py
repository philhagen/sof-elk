"""
SOF-ELK® Utils Module
"""
