"""
SOF-ELK® Library Module
"""
